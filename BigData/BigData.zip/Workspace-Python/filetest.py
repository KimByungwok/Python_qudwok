f = open('./demofile.txt')
# 위와 동일
# f = open("demofile.txt", "rt")
print(type(f))
f.close()