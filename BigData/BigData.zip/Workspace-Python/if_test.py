x = 10
y = 20
if (x > y) and (x >= 10):
    print("x가 y보다 작네요")
    print("x의 값은 {}이고 y의 값은 {}입니다.".format(x,y))
print("이건 if문하고 상관 없습니다.")

# x가 10~20사이의 값인지 출력해 보자
if x>=10 and x<=20:
    print("x가 10~20사이의 값이네...")

if 10<= x <=20:
    print("x가 10~20사이의 값이네...")